package com.example.calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.ArithmeticException

class MainActivity : AppCompatActivity() {

    // Last element entered is a number/digit or not
    var lastDigit = false

    // Last element entered is a decimal/dot or not
    var lastDot = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    // function for removing extra zeroes from the end of decimal (for eg. 12.0 -> 12 )
    private fun removeExtraZeroes(value: String): String {
        var newValue: String = value
        if (value.contains(".0")) {
            newValue = value.substring(0, value.length - 2)
        }
        return newValue
    }

    // Calculates the result and sets the value to be displayed at textView
    fun onEqual(view: View) {
        // Only run when last element is a number
        if (lastDigit) {
            // Storing the value/ text already present in textView into tvValue
            var tvValue = tvInput.text.toString()

            // Handling -ve // Prefix represents -ve(when -ve at first position) or +ve(when empty)
            var prefix = ""

            // if entered number is -ve
            if (tvValue.startsWith("-")) {
                prefix = "-"
                // Ignore -ve sign for now
                tvValue = tvValue.substring(1)
            }

            // Calculate the answer
            try {
                if (tvValue.contains("-")) {

                    // Split string into 2 numbers based on operator present in between
                    val splitValue = tvValue.split("-")
                    // first number
                    var one = splitValue[0]
                    // second number
                    var two = splitValue[1]

                    // if number was -ve then append -ve
                    if (prefix == "-") {
                        one = prefix + one
                    }

                    // Calculate the answer and remove extra zeroes from back (refer function declaration)
                    tvInput.text = removeExtraZeroes((one.toDouble() - two.toDouble()).toString())
                } else if (tvValue.contains("+")) {
                    val splitValue = tvValue.split("+")
                    var one = splitValue[0]
                    var two = splitValue[1]

                    if (prefix == "-") {
                        one = prefix + one
                    }

                    tvInput.text = removeExtraZeroes((one.toDouble() + two.toDouble()).toString())
                } else if (tvValue.contains("/")) {
                    val splitValue = tvValue.split("/")
                    var one = splitValue[0]
                    var two = splitValue[1]

                    if (prefix == "-") {
                        one = prefix + one
                    }

                    tvInput.text = removeExtraZeroes((one.toDouble() / two.toDouble()).toString())
                } else {
                    val splitValue = tvValue.split("*")
                    var one = splitValue[0]
                    var two = splitValue[1]

                    if (prefix == "-") {
                        one = prefix + one
                    }

                    tvInput.text = removeExtraZeroes((one.toDouble() * two.toDouble()).toString())
                }
            }
            // If any ArithmeticException occurs then
            catch (e: ArithmeticException) {
                e.printStackTrace()
            }
        }
    }

    // When digit is pressed then append digit to textView value and set lastDigit to true
    fun onDigit(view: View) {
        lastDigit = true
        tvInput.append((view as Button).text)
    }

    // When Clear is pressed then set textView value to empty string. Set lastDigit and lastDot to false
    fun onClickClear(view: View) {
        lastDot = false
        lastDigit = false
        tvInput.text = ""
    }

    // When decimal is pressed check if last entered value was number and decimal is not present already.
    // If so then append decimal else ignore
    fun onDecimal(view: View) {
        if (lastDigit && !lastDot) {
            tvInput.append(".")
            lastDigit = false
            lastDot = true
        }
    }

    // When any operator is pressed then check if-> last entered value was digit else->ignore and
    // if-> the number is -ve else->ignore
    fun onOperator(view: View) {
        if (lastDigit && !isOperatorAdded(tvInput.text.toString())) {
            tvInput.append((view as Button).text)
            lastDigit = false
            lastDot = false
        }
    }

    // Return false when number is -ve and true when any operator is already present
    private fun isOperatorAdded(value: String): Boolean {
        return if (value.startsWith("-")) {
            false
        } else {
            value.contains("/") || (value.contains("*")) || (value.contains("+")) || (value.contains(
                "-"
            ))
        }
    }
}